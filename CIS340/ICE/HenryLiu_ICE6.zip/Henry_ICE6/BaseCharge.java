package Henry_ICE6;

public interface BaseCharge {
	static final double BASE_CHARGE_SINGLE_FAMILY = 13.21;
	static final double BASE_CHARGE_DUPLEX = 15.51;

}
